package com.voterra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoterraApplicationTests {

	@Test
	void contextLoads() {
	}

}
